<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="g-sidenav-show  bg-gray-200">
<?php if(Auth::check()): ?>
  <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;" style="text-decoration: none">Admin</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page"><a style="text-decoration: none" href="<?php echo e(route('lst_order')); ?>">List order</a></li>
          </ol>        
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
          <form class="card-body" action="<?php echo e(route('search_order')); ?>"; method="GET" role="search">
          <?php echo e(csrf_field()); ?>

            <div class="input-group input-group-outline">
              <!-- <label class="form-label">Search ...</label> -->
              <input type="text" id="search_order" name="search_order" placeholder="Search..." class="form-control" style="border-radius: 6px;" />
              <button type="submit" style="border: none; margin-left: -35px;background-color: #F0F2F5;"><i class="fas fa-search"></i></button>
            </div>
            </form>
          </div>
        <?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </nav>
    <hr>
    <!-- End Navbar -->
    <!-- Content -->
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
        <div class="col-12">
              <?php if(session('message')): ?>
              <div class="col-offset-5 col-12 alter alter-success "
                  style="margin-top: -30px;color: #52AC56;font-size: 20px;font-style: italic;margin-left:45%">
                  <?php echo e(session('message')); ?>

              </div>
              <?php endif; ?>
          <div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
            <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3 row">
                  <div class="col-sm-8 col-lg-8"  >
                  <h6 class="text-white text-capitalize ps-3">List order</h6>
                  </div>
                  <div class="col-sm-4 col-lg-4 row">
                  </div>   
                </div>
            </div>
            <div class="card-body px-0 pb-2">
              <div class="table-responsive p-0">               
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>                   
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">No</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name Order</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Number Phone</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Address</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Attenion</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Product</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Price</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Quantity</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Total Price</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Date Order</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Payment</th>                   
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">User Id</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Create Date</th>
                    </tr>
                  </thead>
                  <tbody>                
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                 
                    <tr>
                      <td><?php echo e($order->row); ?></td>
                      <td><?php echo e($order->name_order); ?></td>
                      <td><?php echo e($order->number_phone); ?></td> 
                      <td><?php echo e($order->address); ?></td>
                      <td><?php echo e($order->attention); ?></td>                
                      <td><?php echo e($order->prd_id); ?></td>
                      <td><?php echo e($order->price); ?></td>
                      <td><?php echo e($order->quantity); ?></td>
                      <td><?php echo e($order->total_price); ?></td>
                      <td><?php echo e($order->date_order); ?></td>
                      <td><?php echo e($order->payment_id); ?></td>
                      <td><?php echo e($order->user_id); ?></td>
                      <td class="align-middle text-center text-sm">
                      <?php if($order->status == 'Active'): ?>
                        <span class="badge badge-sm bg-gradient-success"><?php echo e($order->status); ?></span>
                      <?php else: ?>
                        <span class="badge badge-sm bg-gradient-danger"><?php echo e($order->status); ?></span>
                      <?php endif; ?>             
                      </td>  
                      <td><?php echo e($order->created_at); ?></td>                   
                    </tr>                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>      
              </div>           
            </div>
          </div>
        </div>
        </div>
      </div>
      <div class="pagination"><?php echo e($orders->links()); ?></div>
      <br>
      <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- End Content -->
  </main>
  
  <?php echo $__env->make('admin.fixedplugin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--   Core JS Files   -->
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/chartjs.min.js"></script>

<!-- <script src="./assets/js/sales/master.js"></script> -->
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/material-dashboard.min.js?v=3.0.0"></script>
  <?php else: ?>
  <?php endif; ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\Sales211221a\resources\views/admin/orders/list_orders.blade.php ENDPATH**/ ?>