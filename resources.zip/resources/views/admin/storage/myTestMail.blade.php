<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1>{{$data['title']}}</h1>
    <p>{{$data['body']}}</p>
    <p>{{$data['signature']}}</p>
    
    <p>Thank you</p>
</body>
</html>